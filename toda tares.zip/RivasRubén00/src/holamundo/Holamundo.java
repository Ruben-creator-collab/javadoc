package holamundo;

public class Holamundo {

	public static void main(String[] args) {
		System.out.print("Hola Mundo!!!");

	}

}
