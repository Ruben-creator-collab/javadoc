package rivas;

public class Ejercicio2 {

	public static void main(String[] args) {
		
        // Nombres de los meses del año
        String[] meses = {
            "Ene", "Feb", "Mar",
            "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"
        };
        
        String[] sucursales = {
        		"Málaga", "Sevilla", "Granada"
        };
		
		int [][] ventas = new int [3][12];
		for (int contador = 0; contador < ventas.length; contador++) {
			for (int i = 0; i < ventas.length; i++) {
				ventas [contador][i] = (int) (Math.random()*500);
			}
		}
		
		mostrarMatriz(ventas);
	}
	
	public static void mostrarMatriz(int[][] ventas ) {
//		for(int mesesCon = 0; mesesCon < ventas.length; mesesCon++) {
//			for(int sucursalesCon = 0; sucursalesCon < ventas.length; sucursalesCon++) {
//				System.out.println(sucursales[sucursalesCon] + meses[mesesCon] + "\t");
//			}
//		}
		for (int mes = 0; mes < ventas.length; mes++) {
			for (int dia = 0; dia < ventas[mes].length; dia++) {
				System.out.print(ventas[mes][dia] + "\t");
			}
			System.out.println();
		}
	}

}
