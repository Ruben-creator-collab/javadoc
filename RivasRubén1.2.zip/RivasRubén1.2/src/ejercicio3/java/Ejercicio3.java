/*
 * Descripción: Esto es un programa el cuál dice el valor de dos variables y tambien mi cargo y nombre
 * Autor: Rubén
 * Fecha: 25/09/25
 */

package ejercicio3.java;


public class Ejercicio3 {

	public static void main(String[] args) {

		
		int num1 = 1, num2 = 1;
		char char1, char2 = 'a';
		
		String cargo, nombre;
		cargo = "Capitán";
		nombre = "Rubén";
		
		System.out.println("Este es el valor de la variable num1: " + num1 + ", y este es el valor de la variable num2: " + num2);
		System.out.println("Bienvenido, " + cargo + " " + nombre);
		

	}

}
