/*
 * Descripción: Programa de java que convierte euros en pesetas y viceversa
 * Autor: Rubén Rivas
 * Fecha: 01/10/25
 */
package ejercicio2.java;

import java.util.Scanner;

public class Ejercicio2 {

	public static void main(String[] args) {
		Scanner datos = new Scanner (System.in);
		
		System.out.println("Conversor de euros a pesetas");
		System.out.println("----------------------------");
		
		double euros;
		System.out.print("Dime cuantos euros quieres pasar a pesetas: ");
		euros = datos.nextDouble();
		euros = euros * 166.386;
		
		
		System.out.println("Estos son tus euros en pesetas: " + euros);
		
		System.out.println("Conversor de pesetas a euros");
		System.out.println("----------------------------");
		
		double pesetas;
		System.out.print("Dime cuantas pesetas quieres pasar a euros: ");
		pesetas = datos.nextDouble();
		pesetas = pesetas / 166.386;
		
		System.out.println("Estas son tus pesetas en euros: " + pesetas);
		
		
		
		

	}

}
