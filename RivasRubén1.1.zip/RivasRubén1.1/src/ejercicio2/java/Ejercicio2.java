/*
 * Descripción: Voy a hacer el ejercicio2.java
 * Autor: Rubén
 * Fecha: 24/09/25
 */
package ejercicio2.java;

public class Ejercicio2 {

	public static void main(String[] args) {
		System.out.println("Desarrollo de Aplicaciones WEB/Multiplataforma");
		System.out.println("1DAW /DAM");
		System.out.println("Módulos:\n" + "PRO\n" + "SIS\n"); // Declaro en un print los módulos y hago \n para saltar de línea

	}

}
