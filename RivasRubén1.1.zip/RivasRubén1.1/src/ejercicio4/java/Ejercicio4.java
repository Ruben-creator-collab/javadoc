/*
 * Descripción: Voy a hacer el ejercicio4.java
 * Autor: Rubén
 * Fecha: 24/09/25
 */
package ejercicio4.java;

public class Ejercicio4 {

	public static void main(String[] args) {
		
		byte Byte = 8;
		System.out.println("El valor de la variable de tipo byte (Byte) es: " + Byte);
		
		short corto = 12;
		System.out.println("El valor de la variable de tipo short (corto) es: " + corto);
		
		int entero = 134;
		System.out.println("El valor de la variable de tipo entero (entero) es: " + entero);
		
		char caracter = 'a';
		System.out.println("El valor de la variable de tipo char (caracter) es: " + caracter);
		
		double decimal = 1.54123123;
		System.out.println("El valor de la variable de tipo decimal (decimal) es: " + decimal);
		
		float flotante = 35.23f;
		System.out.println("El valor de la variable de tipo float (flotante) es: " + flotante);
		
		String CadenaCaracteres = "Alberto";
		System.out.println("El valor de la variable de tipo String (cadenaCaracteres) es: " + CadenaCaracteres);
		
		
		
	}

}
