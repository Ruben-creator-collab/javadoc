/*
 * Descripción: Voy a hacer el ejercicio3.java
 * Autor: Rubén
 * Fecha: 24/09/25
 */
package ejercicio3.java;

public class Ejercicio3 {

	public static void main(String[] args) {
		int num1 = 0;
		int num2 = 0;
		System.out.println("Valor de num1: " + num1 + " y el valor de num2 " + num2);
		
		double val1 = 1.34;
		double val2 = 1.75;
		System.out.println("Valor de val1: " + val1 + " y el valor de val2 " + val2);
		
		String nombre ="Rubén";
		String apellidos = "Rivas Flores";
		System.out.println("Mi nombre es " + nombre + " y mis apellidos " + apellidos);
		
	}

}
