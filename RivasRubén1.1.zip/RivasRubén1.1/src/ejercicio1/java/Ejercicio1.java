/*
 * Descripción: Voy a hacer el ejercicio1.java
 * Autor: Rubén
 * Fecha: 24/09/25
 */
package ejercicio1.java;

public class Ejercicio1 {

	public static void main(String[] args) {
		System.out.println("Este es mi primer programa Java"); // Declaro un print para decir que este es mi primer programa

	}

}
