/*
 * Descripción: Pedir la edad y mostrar si es mayor de edad
 * Autor: Rubén Rivas
 * Fecha: 02/10/25
 */
package estructuraSi;

import java.util.Scanner;

public class EjemploSi {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int edad;
		System.out.print("Dime tu edad: ");
		edad = sc.nextInt();
		
		if (edad >=18 && edad <= 30) {
			System.out.println("Eres joven");
		}
		
		
		
		
		
		
	}

}
